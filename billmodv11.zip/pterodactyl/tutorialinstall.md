𝗝𝗔𝗡𝗚𝗔𝗡 𝗗𝗜 𝗝𝗨𝗔𝗟 𝗕𝗘𝗟𝗜𝗞𝗔𝗡!! 
#DASARJB

𝗖𝗔𝗥𝗔 𝗜𝗡𝗦𝗧𝗔𝗟𝗟
> Ekstrak Dulu File Ini Jadi Folder
> Upload File Ini ke /var/www
Comandnya 
$ sudo mkdir -p /etc/apt/keyrings
$ curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | sudo gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg
$ echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_16.x nodistro main" | sudo tee /etc/apt/sources.list.d/nodesource.list
$ sudo apt update
$ apt install nodejs -y
$ npm i -g yarn
$ cd /var/www/pterodactyl
$ yarn 
$ php artisan billing:install stable 
 License nya : RAIN
$ yarn build:production